To run the code you have 3 alternatives:
* Run them individually
* Run main and choose which code to run using command
* Run the app and choose which problem to run
With all these options you need to open MATLAB first then click:
* Open the code or main and then click run
* Go to the folder in your OS then click on the app "RUN_THIS.mlapp"